# std_deviation
project solution c105
