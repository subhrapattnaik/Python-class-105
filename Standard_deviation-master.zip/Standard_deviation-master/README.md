# Standard_deviation
solution for c105
